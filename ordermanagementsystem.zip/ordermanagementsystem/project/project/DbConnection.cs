﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace project
{
    public class DbConnection:DbContext
    {
        public DbConnection() : base("DBConnection")
        {
            Database.SetInitializer<DbConnection>(null);
        }
    }
}