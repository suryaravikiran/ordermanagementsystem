﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace project.Models
{
    public class Product
    {
        public string Name { get; set; }
        public Decimal Weight { get; set; }
        public int Height { get; set; }
        public string Images { get; set; }
        public string SKU { get; set; }
        public string Barcode { get; set; }
        public int AvailableQty { get; set; }
    }
    public class ShippingAddress
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public long Zipcode { get; set; }
        public long PhoneNumber { get; set; }       
    }
    public class BuyerInformation
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public long Zipcode { get; set; }
        public long PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
    }

    public class OrderItems
    {
        public int OrderNumber { get; set; }
        public OrdStatus status { get; set; }
        public int Qunatity { get; set; }
        public string Name { get; set; }
        public Decimal Weight { get; set; }
        public int Height { get; set; }
        public string Images { get; set; }
        public string SKU { get; set; }
        public string Barcode { get; set; }
        public int AvailableQty { get; set; }
    }
    public class OrderItem
    {
        public int OrderNumber { get; set; }        
        public int Qunatity { get; set; }
        public List<Product> Products { get; set; }        
    }

    public class Order
    {
        public BuyerInformation BuyerInformation { get; set; }
        public OrdStatus OrderStatus { get; set; }
        public ShippingAddress ShippingAddress { get; set; }
        public List<OrderItem> OrderItems { get; set; }
    }
    public class ProductDetails
    {
        public int id { get; set; }
        public string Name { get; set; }
        public Decimal Weight { get; set; }
        public int Height { get; set; }
        public string Images { get; set; }
        public string SKU { get; set; }
        public string Barcode { get; set; }
        public int AvailableQty { get; set; }
    }
    public class InsertStatus
    {
        public long ProductId { get; set; }
        public bool Updated { get; set; }
    }    
    
    public class updatestatus
    {
        public BuyerInformation BuyerInformation { get; set; }
        public OrdStatus OrderStatus { get; set; }
        public ShippingAddress ShippingAddress { get; set; }
        public int OrderNumber { get; set; }
    }
        
}