﻿using Microsoft.Owin.Security.OAuth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Threading.Tasks;

namespace project
{
    public class MyAuthorizationServerProvider : OAuthAuthorizationServerProvider
    {
        public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated(); //i have validate clent
        }
        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            var identity = new ClaimsIdentity(context.Options.AuthenticationType);
            if (context.UserName == "Buyer" && context.Password == "Buyer")
            {
                identity.AddClaim(new Claim(ClaimTypes.Role, "Buyer"));
                identity.AddClaim(new Claim("username", "Buyer"));
                identity.AddClaim(new Claim("password", "Buyer"));
                identity.AddClaim(new Claim(ClaimTypes.Name, "BuyerInformation"));
                context.Validated(identity);
            }
            else if (context.UserName == "Administrator" && context.Password == "Administrator")
            {
                identity.AddClaim(new Claim(ClaimTypes.Role, "Administrator"));
                identity.AddClaim(new Claim("username", "Administrator"));
                identity.AddClaim(new Claim("password", "Administrator"));
                identity.AddClaim(new Claim(ClaimTypes.Name, "AdministratorInformation"));
                context.Validated(identity);
            }
            else
            {
                context.SetError("invalid_grant", "provided username and password is incorrect");
                return;
            }

        }
    }
}