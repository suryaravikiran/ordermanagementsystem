﻿using project.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Web.Http;


namespace project.Controllers
{
    [RoutePrefix("api/ordermanagementsystem")]
    public class OrdersController : ApiController
    {

        #region viewOrderDetails
        /// <summary>
        /// View Order
        /// </summary>
        /// <returns></returns>
        [HttpGet, Route("vieworders")]
        public List<Order> ViewOrder()
        {
            List<Order> lstOrder = new List<Order>();
            try
            {
                Dal objDal = new Dal();
                List<OrderItems> lstOrderItem = objDal.ReadAllOrder();
                if (lstOrderItem != null && lstOrderItem.Count > 0)
                    lstOrder = OrderDetails(lstOrderItem,false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstOrder;
        }
        #endregion

        #region Add orders
        /// <summary>
        /// Add orders
        /// </summary>
        /// <param name="lstOrder"></param>
        /// <returns></returns>
        [HttpPost, Route("addorder")]
        public HttpResponseMessage AddOrder(Order objOrder)
        {
            Dal objDal = new Dal();
            string errorMessage = string.Empty;
            string commaProductsname = string.Empty;
            List<InsertStatus> lstinsertstatus = new List<InsertStatus>();
            try
            {
                if (objOrder.OrderItems != null && objOrder.OrderItems.Count > 0 && objOrder.OrderStatus == OrdStatus.Placed)
                {
                    List<string> lstName = new List<string>();
                    if (objOrder.OrderItems[0].Products != null && objOrder.OrderItems[0].Products.Count > 0)
                    {
                        for (int j = 0; j < objOrder.OrderItems[0].Products.Count; j++)
                            lstName.Add(objOrder.OrderItems[0].Products[j].Name);
                    }
                    if (lstName != null && lstName.Count > 0)
                        commaProductsname = string.Join(",", lstName);
                    if (!string.IsNullOrEmpty(commaProductsname) && objOrder.OrderItems[0].OrderNumber > 0)
                    {
                        object objdata = new object();

                        objdata = objDal.OrderExist(objOrder.OrderItems[0].OrderNumber, commaProductsname);

                        bool result = false;
                        List<ProductDetails> lstProductDetails = new List<ProductDetails>();
                        if (objdata != null)
                        {
                            result = (bool)objdata.GetType().GetProperty("resu").GetValue(objdata);
                            lstProductDetails = (List<ProductDetails>)objdata.GetType().GetProperty("lstproduct").GetValue(objdata);
                        }

                        if (!result && lstProductDetails != null && lstProductDetails.Count == lstName.Count && objOrder.OrderItems[0].OrderNumber > 0)
                        {

                            string commaProductIds = string.Empty;
                            if (objOrder.OrderItems[0] != null && objOrder.OrderItems[0].Products != null && objOrder.OrderItems[0].Products.Count > 0)
                            {
                                commaProductIds = string.Join(",", lstProductDetails.Select(a => a.id).ToList());
                                if (!string.IsNullOrEmpty(commaProductIds))
                                    commaProductIds = commaProductIds + ",";
                            }
                            lstinsertstatus = objDal.addOrder(objOrder.OrderItems[0].OrderNumber, objOrder.OrderItems[0].Qunatity, commaProductIds);
                            if (lstinsertstatus != null && lstinsertstatus.Count > 0)
                                errorMessage = checkingvalidation(lstinsertstatus);
                        }
                        else if (!result && objOrder.OrderItems[0].OrderNumber > 0)
                        {
                            if (lstProductDetails != null && lstProductDetails.Count > 0 && objOrder.OrderItems[0] != null && objOrder.OrderItems[0].Products != null && objOrder.OrderItems[0].Products.Count > 0)
                            {
                                List<Product> data = new List<Product>();
                                data = objOrder.OrderItems[0].Products.Where(p => lstProductDetails.All(p2 => !string.IsNullOrEmpty(p2.Name) && !string.IsNullOrEmpty(p.Name) && p2.Name.ToLower() != p.Name.ToLower())).ToList();
                                if (data != null && data.Count > 0)
                                    objDal.addproducts(data);

                                lstinsertstatus = commoncodeforadd(objOrder.OrderItems[0].Products, objOrder.OrderItems[0].OrderNumber, objOrder.OrderItems[0].Qunatity);
                                if (lstinsertstatus != null && lstinsertstatus.Count > 0)
                                    errorMessage = checkingvalidation(lstinsertstatus);
                            }
                            else
                            {
                                if (objOrder.OrderItems[0] != null && objOrder.OrderItems[0].Products != null && objOrder.OrderItems[0].Products.Count > 0)
                                {
                                    objDal.addproducts(objOrder.OrderItems[0].Products);
                                    lstinsertstatus = commoncodeforadd(objOrder.OrderItems[0].Products, objOrder.OrderItems[0].OrderNumber, objOrder.OrderItems[0].Qunatity);
                                    if (lstinsertstatus != null && lstinsertstatus.Count > 0)
                                        errorMessage = checkingvalidation(lstinsertstatus);
                                }
                            }
                        }
                        else
                            errorMessage = "please change order number in orderitem,order number are unqiue";
                    }
                }
                else
                    errorMessage = "please change status as Placed/Orderitem should be mandatory";
            }
            catch (Exception ex)
            {
                errorMessage = "Request failed";
            }
            if (lstinsertstatus != null && lstinsertstatus.Count > 0)
            {
                if (objOrder != null && objOrder.OrderItems[0] != null && objOrder.OrderItems[0].OrderNumber > 0)
                {
                    if (objOrder.BuyerInformation != null)
                        objDal.InsertAndUpdateBuyerInformation(objOrder.OrderItems[0].OrderNumber, objOrder.BuyerInformation);
                    if (objOrder.ShippingAddress != null)
                        objDal.InsertAndUpdateShippingAddress(objOrder.OrderItems[0].OrderNumber, objOrder.ShippingAddress);
                    if (!string.IsNullOrEmpty(objOrder.BuyerInformation.EmailAddress) && !string.IsNullOrEmpty(commaProductsname))
                    {
                        bool ismail = true;
                        for (int i = 0; i < lstinsertstatus.Count; i++)
                        {
                            if (!lstinsertstatus[i].Updated)
                            {
                                ismail = false;
                                break;
                            }
                        }
                        if (ismail)
                            MailSending(objOrder.BuyerInformation.EmailAddress, commaProductsname);
                    }
                }
                var response = Request.CreateResponse(HttpStatusCode.OK, new
                {
                    Message = errorMessage,
                    productIds = lstinsertstatus,
                });
                return response;
            }
            else
            {
                var response = Request.CreateResponse(HttpStatusCode.OK, new
                {
                    ErrorMessage = errorMessage
                });
                return response;
            }
        }
        #endregion

        #region orderDetails
        /// <summary>
        /// order Details
        /// </summary>
        /// <param name="lstOrderItem"></param>
        /// <returns></returns>
        private List<Order> OrderDetails(List<OrderItems> lstOrderItem,bool buyer)
        {
            List<Order> lstorder = new List<Order>();
            try
            {
                for (int i = 0; i < lstOrderItem.Count; i++)
                {
                    Order objorder = new Order();
                    if (lstOrderItem[i].OrderNumber > 0 && lstorder != null && lstorder.Count > 0 && lstorder.Exists(a => a.OrderItems.Exists(b => b.OrderNumber == lstOrderItem[i].OrderNumber)))
                    {
                        for (int j = 0; j < lstorder.Count; j++)
                        {
                            if (lstorder[j].OrderItems != null && lstorder[j].OrderItems.Count > 0)
                            {
                                for (int k = 0; k < lstorder[j].OrderItems.Count; k++)
                                {
                                    if (lstorder[j].OrderItems[k].OrderNumber == lstOrderItem[i].OrderNumber)
                                    {
                                        lstorder[j].OrderItems[k].Products.Add(new Product() { Name = lstOrderItem[i].Name, Weight = lstOrderItem[i].Weight, AvailableQty = lstOrderItem[i].AvailableQty, Barcode = lstOrderItem[i].Barcode, Height = lstOrderItem[i].Height, Images = lstOrderItem[i].Images, SKU = lstOrderItem[i].SKU });
                                    }
                                }
                            }
                        }
                    }
                    else
                    {                       
                        if (buyer)
                        {
                            
                            BuyerInformation objBuyerInformation = BuyerInformation(lstOrderItem[i].OrderNumber);
                            if (objBuyerInformation!=null)
                            {
                                objorder.BuyerInformation = objBuyerInformation;
                                objorder.ShippingAddress = ShippingAddress(lstOrderItem[i].OrderNumber);
                                objorder.OrderStatus = lstOrderItem[i].status;
                                OrderItem objorderitem = new OrderItem();
                                objorderitem.OrderNumber = lstOrderItem[i].OrderNumber;
                                objorderitem.Qunatity = lstOrderItem[i].Qunatity;
                                objorderitem.Products = new List<Product>();
                                objorderitem.Products.Add(new Product() { Name = lstOrderItem[i].Name, Weight = lstOrderItem[i].Weight, AvailableQty = lstOrderItem[i].AvailableQty, Barcode = lstOrderItem[i].Barcode, Height = lstOrderItem[i].Height, Images = lstOrderItem[i].Images, SKU = lstOrderItem[i].SKU });
                                objorder.OrderItems = new List<OrderItem>();
                                objorder.OrderItems.Add(objorderitem);
                                lstorder.Add(objorder);
                            }

                        }
                        else
                        {
                            objorder.BuyerInformation = BuyerInformation(lstOrderItem[i].OrderNumber);
                            objorder.ShippingAddress = ShippingAddress(lstOrderItem[i].OrderNumber);
                            objorder.OrderStatus = lstOrderItem[i].status;
                            OrderItem objorderitem = new OrderItem();
                            objorderitem.OrderNumber = lstOrderItem[i].OrderNumber;
                            objorderitem.Qunatity = lstOrderItem[i].Qunatity;
                            objorderitem.Products = new List<Product>();
                            objorderitem.Products.Add(new Product() { Name = lstOrderItem[i].Name, Weight = lstOrderItem[i].Weight, AvailableQty = lstOrderItem[i].AvailableQty, Barcode = lstOrderItem[i].Barcode, Height = lstOrderItem[i].Height, Images = lstOrderItem[i].Images, SKU = lstOrderItem[i].SKU });
                            objorder.OrderItems = new List<OrderItem>();
                            objorder.OrderItems.Add(objorderitem);
                            lstorder.Add(objorder);
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstorder;
        }
        #endregion

        #region BuyerInformation
        /// <summary>
        /// BuyerInformation
        /// </summary>
        /// <returns></returns>
        private BuyerInformation BuyerInformation(int orderNumber)
        {
            BuyerInformation objBuyerInformation = null;
            try
            {
                Dal obj = new Dal();
                objBuyerInformation = obj.BuyerInformation(orderNumber);
            }
            catch (Exception ex) { }

            return objBuyerInformation;
        }
        #endregion

        #region ShippingAddress
        /// <summary>
        /// ShippingAddress
        /// </summary>
        /// <returns></returns>
        private ShippingAddress ShippingAddress(int orderNumber)
        {
            ShippingAddress objShippingAddress = null;
            try
            {
                Dal dal = new Dal();
                objShippingAddress = dal.ReadShippingAddress(orderNumber);
            }
            catch (Exception ex) { }
            return objShippingAddress;
        }
        #endregion

        #region common code
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lstproducts"></param>
        /// <param name="orderNumber"></param>
        /// <param name="qty"></param>
        /// <returns></returns>
        private List<InsertStatus> commoncodeforadd(List<Product> lstproducts, int orderNumber, int qty)
        {
            List<InsertStatus> lstinsertstatus = new List<InsertStatus>();
            Dal objDal = new Dal();
            string commaProductIds = string.Empty;
            try
            {
                List<ProductDetails> lstproddetails = objDal.readProducts();
                if (lstproddetails != null && lstproddetails.Count > 0)
                {
                    lstproddetails = lstproddetails.FindAll(p => lstproducts.Exists(p2 => !string.IsNullOrEmpty(p2.Name) && !string.IsNullOrEmpty(p.Name) && p2.Name.ToLower() == p.Name.ToLower())).Select(p => p).ToList();

                    if (lstproddetails != null && lstproddetails.Count > 0)
                    {
                        commaProductIds = string.Join(",", lstproddetails.Select(a => a.id).ToList());
                        if (!string.IsNullOrEmpty(commaProductIds))
                        {
                            commaProductIds = commaProductIds + ",";
                            lstinsertstatus = objDal.addOrder(orderNumber, qty, commaProductIds);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstinsertstatus;
        }

        #endregion

        #region validation
        /// <summary>
        /// validation
        /// </summary>
        /// <param name="lstinsertstatus"></param>
        /// <returns></returns>
        private string checkingvalidation(List<InsertStatus> lstinsertstatus)
        {
            string message = string.Empty;
            if (lstinsertstatus != null && lstinsertstatus.Count > 0)
            {
                message = "order placed successfully";
                //validation message
                for (int i = 0; i < lstinsertstatus.Count; i++)
                {
                    if (!lstinsertstatus[i].Updated)
                    {
                        message = "Please check required quantity not in available for the products.";
                        break;
                    }
                }

            }
            return message;
        }
        #endregion

        #region DeleteOrders
        /// <summary>
        /// DeleteOrders
        /// </summary>
        /// <param name="CommaSepratedIds"></param>
        /// <returns></returns>
        [HttpDelete, Route("deleteorders")]
        public HttpResponseMessage DeleteOrders([FromUri]string ordernumbers)
        {
            bool result = false;
            string errorMessage = string.Empty;
            try
            {
                Dal objDal = new Dal();
                result = objDal.DeleteOrders(ordernumbers);
                if (result)
                    errorMessage = "Orders delete Successfully";
                else
                    errorMessage = "Orders deleted failed";
            }
            catch (Exception ex)
            {
                result = false;
                errorMessage = "Error occured while deleting";
            }
            var response = Request.CreateResponse(HttpStatusCode.OK, new
            {
                Message = errorMessage
            });
            return response;
        }
        #endregion

        #region EditOrder
        /// <summary>
        /// EditOrder
        /// </summary>
        /// <param name="orderid"></param>
        /// <returns></returns>
        [HttpGet, Route("{ordernumber}/editorder")]
        public Order EditOrder(int ordernumber)
        {
            Order objOrder = new Order();
            try
            {
                Dal objDal = new Dal();
                objOrder = objDal.EditOrder(ordernumber);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objOrder;
        }
        #endregion

        #region mail sending for order placed
        /// <summary>
        /// mail sending for order placed
        /// </summary>       
        /// <param name="productName"></param>
        /// <param name="toEmailAddress"></param>
        private void MailSending(string toEmailAddress, string productname)
        {
            try
            {
                string username = string.Empty;
                string password = string.Empty;
                string fromemailAddress = string.Empty;
                string smtpHost = string.Empty;
                int smtpPort = 0;
                if (!string.IsNullOrEmpty(Convert.ToString(ConfigurationManager.AppSettings["fromEmailAddress"])))
                    fromemailAddress = Convert.ToString(ConfigurationManager.AppSettings["fromEmailAddress"]);
                if (!string.IsNullOrEmpty(Convert.ToString(ConfigurationManager.AppSettings["password"])))
                    password = Convert.ToString(ConfigurationManager.AppSettings["password"]);
                if (!string.IsNullOrEmpty(Convert.ToString(ConfigurationManager.AppSettings["username"])))
                    username = Convert.ToString(ConfigurationManager.AppSettings["username"]);
                if (!string.IsNullOrEmpty(Convert.ToString(ConfigurationManager.AppSettings["smtpHost"])))
                    smtpHost = Convert.ToString(ConfigurationManager.AppSettings["smtpHost"]);
                if (!string.IsNullOrEmpty(Convert.ToString(ConfigurationManager.AppSettings["smtpPort"])))
                    smtpPort = int.Parse(ConfigurationManager.AppSettings["smtpPort"]);

                if (!string.IsNullOrEmpty(fromemailAddress) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(smtpHost) && smtpPort > 0)
                {
                    MailMessage message = new MailMessage();
                    message.From = new MailAddress(fromemailAddress);
                    message.To.Add(toEmailAddress);
                    message.Subject = "Order Management System";
                    message.IsBodyHtml = true;
                    message.Body = "Order has been submitted for Products like " + productname;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = smtpHost;
                    smtp.Port = smtpPort;
                    smtp.EnableSsl = true;
                    smtp.Credentials = new NetworkCredential(username.Trim(), password.Trim());
                    smtp.Send(message);
                }
            }
            catch (Exception ex) { }

        }
        #endregion

        #region updatestatus
        /// <summary>
        /// updatestatus
        /// </summary>
        /// <param name="objupdate"></param>
        /// <returns></returns>
        [HttpPut,Route("updatestatus")]
        public HttpResponseMessage updatestatus(updatestatus objupdate)
        {
            string errorMessage = string.Empty;
            try
            {
                if (objupdate != null && objupdate.OrderNumber > 0)
                {
                    Dal objdal = new Dal();
                    bool result = objdal.validateOrderId(objupdate.OrderNumber);
                    if (result)
                    {
                        if (objupdate.BuyerInformation != null && objupdate.ShippingAddress != null && (int)objupdate.OrderStatus > 0)
                        {
                            objdal.InsertAndUpdateBuyerInformation(objupdate.OrderNumber, objupdate.BuyerInformation);
                            objdal.InsertAndUpdateShippingAddress(objupdate.OrderNumber, objupdate.ShippingAddress);
                            objdal.UpdateStatusOrder(objupdate.OrderStatus, objupdate.OrderNumber);
                            errorMessage = "update order successfully";
                        }
                        else
                            errorMessage = "please fill all fields for buyerinfo,shippingaddress,status";
                    }
                    else
                        errorMessage = "invalid order number";
                }
                else
                    errorMessage = "please fill order number";
            }
            catch (Exception ex)
            {
                errorMessage = "error occured";
            }
            var response = Request.CreateResponse(HttpStatusCode.OK, new
            {
                Message = errorMessage
            });
            return response;
        }
        #endregion

        #region buyer
        /// <summary>
        /// buyer
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Buyer")]
        [HttpGet,Route("buyer")]
        public List<Order> BuyerOrders()
        {
            List<Order> lstOrder = new List<Order>();
            try
            {
                Dal objDal = new Dal();
                List<OrderItems> lstOrderItem = objDal.ReadAllOrder();
                if (lstOrderItem != null && lstOrderItem.Count > 0)
                    lstOrder = OrderDetails(lstOrderItem,true);

            }
            catch(Exception ex) { }
            return lstOrder;
        }
        #endregion

        #region administrator
        /// <summary>
        /// administrator
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Administrator")]
        [HttpGet, Route("administrator")]
        public List<Order> Administrator()
        {
            List<Order> lstOrder = new List<Order>();
            try
            {
                Dal objDal = new Dal();
                List<OrderItems> lstOrderItem = objDal.ReadAllOrder();
                if (lstOrderItem != null && lstOrderItem.Count > 0)
                    lstOrder = OrderDetails(lstOrderItem,false);
            }
            catch(Exception ex) { }
            return lstOrder;
        }
        #endregion
    }
}
