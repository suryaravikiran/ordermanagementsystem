﻿using project.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data;
using System.Data.Common;
using System.Data.Entity.Infrastructure;

namespace project
{
    public class Dal
    {
        #region AddProducts
        /// <summary>
        /// addproducts
        /// </summary>
        /// <param name="lstProducts"></param>
        public void addproducts(List<Product> lstProducts)
        {
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    foreach (Product objpro in lstProducts)
                    {
                        objconnection.Database.ExecuteSqlCommand("SP_InsertProducts @name,@weight,@height,@image,@sku,@barcode,@availableqty",
                         new SqlParameter("@name", objpro.Name),
                         new SqlParameter("@weight", objpro.Weight),
                         new SqlParameter("@height", objpro.Height),
                         new SqlParameter("@image", objpro.Images),
                         new SqlParameter("@sku", objpro.SKU),
                         new SqlParameter("@barcode", objpro.Barcode),
                         new SqlParameter("@availableqty", objpro.AvailableQty));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region AddOrder
        /// <summary>
        /// addorder
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <param name="qunatity"></param>
        /// <param name="commaProductIds"></param>
        /// <returns></returns>
        public List<InsertStatus> addOrder(int orderNumber, int qunatity, string commaProductIds)
        {
            List<InsertStatus> lstinsertstatus = null;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    lstinsertstatus = objconnection.Database.SqlQuery<InsertStatus>("SP_insertOrders @orderid,@qty,@productsid,@status",
                        new SqlParameter("@orderid", orderNumber),
                        new SqlParameter("@qty", qunatity),
                        new SqlParameter("@productsid", commaProductIds),
                        new SqlParameter("@status", (int)OrdStatus.Placed)
                        ).ToList();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstinsertstatus;
        }
        #endregion

        #region ReadProducts
        /// <summary>
        /// readProducts
        /// </summary>
        /// <returns></returns>
        public List<ProductDetails> readProducts()
        {
            List<ProductDetails> lstproductdetails = null;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    lstproductdetails = objconnection.Database.SqlQuery<ProductDetails>("select* from Products").ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstproductdetails;
        }
        #endregion

        #region OrderExist
        /// <summary>
        /// OrderExist
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <param name="commaProductsname"></param>
        /// <returns></returns>
        public object OrderExist(int orderNumber, string commaProductsname)
        {
            List<ProductDetails> lstProductDetails = new List<ProductDetails>();
            bool result = false;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.Initialize(force: false);
                    var cmd = objconnection.Database.Connection.CreateCommand();
                    cmd.CommandText = "SP_isExistOrder";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("orderid", orderNumber));
                    cmd.Parameters.Add(new SqlParameter("name", commaProductsname));
                    cmd.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    objconnection.Database.Connection.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {

                        result = ((IObjectContextAdapter)objconnection)
                            .ObjectContext
                           .Translate<bool>(reader).FirstOrDefault();
                        reader.NextResult();
                        lstProductDetails = ((IObjectContextAdapter)objconnection)
                            .ObjectContext
                           .Translate<ProductDetails>(reader).ToList();
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return new
            {
                lstproduct = lstProductDetails,
                resu = result
            };
        }
        #endregion

        #region ReadAllOrder
        /// <summary>
        /// ReadAllOrder
        /// </summary>
        /// <returns>List of Order Items</returns>
        public List<OrderItems> ReadAllOrder()
        {
            List<OrderItems> lstOrderItem = null;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    lstOrderItem = objconnection.Database.SqlQuery<OrderItems>("SP_ReadAllOrder").ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstOrderItem;
        }
        #endregion

        #region DeleteOrders
        /// <summary>
        /// DeleteOrder
        /// </summary>
        /// <param name="orderIds"></param>
        /// <returns></returns>
        public bool DeleteOrders(string orderIds)
        {
            bool result = false;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    objconnection.Database.ExecuteSqlCommand("SP_DeleteOrders @orderids",
                         new SqlParameter("@orderids", orderIds)
                         );
                    result = true;
                }
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }
        #endregion

        #region EditOrder
        /// <summary>
        /// EditOrder
        /// </summary>
        /// <param name="orderNumber"></param>       
        /// <returns></returns>
        public Order EditOrder(int orderNumber)
        {
            Order objorder = new Order();
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    List<OrderItems> lstOrderItems = new List<OrderItems>();
                    objconnection.Database.Initialize(force: false);
                    var cmd = objconnection.Database.Connection.CreateCommand();
                    cmd.CommandText = "SP_EditOrder";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("id", orderNumber));
                    cmd.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    objconnection.Database.Connection.Open();
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {

                        lstOrderItems = ((IObjectContextAdapter)objconnection)
                           .ObjectContext
                          .Translate<OrderItems>(reader).ToList();
                        reader.NextResult();

                        objorder.BuyerInformation = ((IObjectContextAdapter)objconnection)
                            .ObjectContext
                           .Translate<BuyerInformation>(reader).FirstOrDefault();

                        reader.NextResult();
                        objorder.ShippingAddress = ((IObjectContextAdapter)objconnection)
                            .ObjectContext
                           .Translate<ShippingAddress>(reader).FirstOrDefault();
                    }
                    if (lstOrderItems != null && lstOrderItems.Count > 0)
                    {
                        objorder.OrderItems = new List<OrderItem>();
                        for (int i = 0; i < lstOrderItems.Count; i++)
                        {
                            objorder.OrderStatus = lstOrderItems[i].status;
                            OrderItem objorderitem = new OrderItem();
                            objorderitem.OrderNumber = lstOrderItems[i].OrderNumber;
                            objorderitem.Qunatity = lstOrderItems[i].Qunatity;
                            objorderitem.Products = new List<Product>();
                            objorderitem.Products.Add(new Product() { Name = lstOrderItems[i].Name, Weight = lstOrderItems[i].Weight, AvailableQty = lstOrderItems[i].AvailableQty, Barcode = lstOrderItems[i].Barcode, Height = lstOrderItems[i].Height, Images = lstOrderItems[i].Images, SKU = lstOrderItems[i].SKU });
                            objorder.OrderItems.Add(objorderitem);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objorder;
        }
        #endregion

        #region Shipping address
        /// <summary>
        /// Shipping address
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <returns></returns>
        public ShippingAddress ReadShippingAddress(int orderNumber)
        {
            ShippingAddress objShippingAddress = null;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    objShippingAddress = objconnection.Database.SqlQuery<ShippingAddress>("SP_ShippingAddress @id",
                        new SqlParameter("@id", orderNumber)).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objShippingAddress;
        }
        #endregion

        #region Buyer information
        /// <summary>
        /// Buyer information
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <returns></returns>
        public BuyerInformation BuyerInformation(int orderNumber)
        {
            BuyerInformation objBuyerInformation = null;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    objBuyerInformation = objconnection.Database.SqlQuery<BuyerInformation>("SP_BuyerInformation @id",
                        new SqlParameter("@id", orderNumber)).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objBuyerInformation;
        }
        #endregion

        #region Insert and Update Shipping address
        /// <summary>
        /// Insert and Update Shipping address
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <param name="objshippingAddress"></param>
        public void InsertAndUpdateShippingAddress(int orderNumber, ShippingAddress objshippingAddress)
        {
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    objconnection.Database.ExecuteSqlCommand("SP_InsertAndUpdateShippingAddress @Id,@FirstName,@LastName,@Address,@PhoneNumber,@City,@State,@ZipCode",
                        new SqlParameter("@Id", orderNumber),
                        new SqlParameter("@FirstName", objshippingAddress.FirstName),
                        new SqlParameter("@LastName", objshippingAddress.LastName),
                        new SqlParameter("@Address", objshippingAddress.Address),
                        new SqlParameter("@PhoneNumber", objshippingAddress.PhoneNumber),
                        new SqlParameter("@City", objshippingAddress.City),
                        new SqlParameter("@State", objshippingAddress.State),
                        new SqlParameter("@ZipCode", objshippingAddress.Zipcode)
                        );
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Insert And Update Buyer information
        /// <summary>
        /// Insert And Update Buyer information
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <param name="objBuyerInformation"></param>
        public void InsertAndUpdateBuyerInformation(int orderNumber, BuyerInformation objBuyerInformation)
        {
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {                   
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    objconnection.Database.ExecuteSqlCommand("SP_InsertAndUpdateBuyerInformation @Id,@FirstName,@LastName,@Address,@PhoneNumber,@City,@State,@ZipCode,@EmailAddress",
                        new SqlParameter("@Id", orderNumber),
                        new SqlParameter("@FirstName", objBuyerInformation.FirstName),
                        new SqlParameter("@LastName", objBuyerInformation.LastName),
                        new SqlParameter("@Address", objBuyerInformation.Address),
                        new SqlParameter("@PhoneNumber", objBuyerInformation.PhoneNumber),
                        new SqlParameter("@City", objBuyerInformation.City),
                        new SqlParameter("@State", objBuyerInformation.State),
                        new SqlParameter("@ZipCode", objBuyerInformation.Zipcode),
                        new SqlParameter("@EmailAddress", objBuyerInformation.EmailAddress)
                        );
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region update status for particuler orders
        /// <summary>
        /// update status for particuler orders
        /// </summary>
        /// <param name="status"></param>
        /// <param name="ordernumber"></param>
        /// <returns></returns>
        public bool UpdateStatusOrder(OrdStatus status,int ordernumber)
        {
            bool updateresult = false;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    objconnection.Database.ExecuteSqlCommand("sp_updatestatus @status,@orderid",
                       new SqlParameter("@status",(int)status),
                       new SqlParameter("@orderid", ordernumber)                      
                       );
                    updateresult = true;
                }
            }            
            catch (Exception ex)
            {
                throw ex;
            }
            return updateresult;
        }
        #endregion

        #region validatefororderid
        /// <summary>
        /// validateOrderId
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <returns></returns>
        public bool validateOrderId(int orderNumber)
        {
            bool result = false;
            try
            {
                using (DbConnection objconnection = new DbConnection())
                {
                    objconnection.Database.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["databaseTimeOut"].ToString());
                    result = objconnection.Database.SqlQuery<bool>("sp_validateOrderId @orderid",
                        new SqlParameter("@orderid", orderNumber)
                        ).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion

    }
}